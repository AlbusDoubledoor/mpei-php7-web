<?php
	if(isset($_POST['username'])&&isset($_POST['password']) &&isset($_POST['role'])) {
		if(!(count($_POST['username']) == count($_POST['password']) && count($_POST['username']) == count($_POST['role'])))
		{
			print('Ошибка регистрации пользователя: [333] Все массивы должны быть одной длины');
			exit;
		}
		$config = file("config.txt");
		$server_db = trim($config[1]);
		$user_db = trim($config[3]);
		$pass_db = trim($config[5]);
		$db_name = trim($config[7]);
		$connection = new mysqli($server_db,$user_db,$pass_db,$db_name);
		if ($connection->connect_errno) {
			print('Ошибка регистрации пользователя: ['.$connection->connect_errno.'] '.$connection->connect_error);
			exit;
		}
		$sql="START TRANSACTION";
		if (!$connection->query($sql))
		{
			print('Ошибка регистрации пользователя: ['.$connection->errno.'] '.$connection->error);
			exit;
		}
		for($idx = 0; $idx < count($_POST['username']); ++$idx) {
			if($_POST['username'][$idx]=="" || $_POST['password'][$idx]=="" ||$_POST['role'][$idx]=="")
			{
				print('Ошибка регистрации пользователя: [222] Один из обязательных параметров пустой');
				$sql = "ROLLBACK";
				$connection->query($sql);
				exit;
			}
			$sql="INSERT INTO users VALUES (0,'".$_POST['username'][$idx]."','".$_POST['password'][$idx]."','".$_POST['role'][$idx]."')";
			if (!$connection->query($sql))
			{
				print('Ошибка регистрации пользователя <'.$_POST['username'][$idx].'>: ['.$connection->errno.'] '.$connection->error);
				$sql = "ROLLBACK";
				$connection->query($sql);
				exit;
			}
		}
		$sql = "COMMIT";
		if ($connection->query($sql))
		{
			print('Успешная регистрация');
		}
		else
		{
			print('Ошибка регистрации пользователя: ['.$connection->errno.'] '.$connection->error);
			exit;
		}
		$connection->close();
	}
	else
		print('Ошибка регистрации пользователя: [111] Не переданы обязательные параметры.');
?>