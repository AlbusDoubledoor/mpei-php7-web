<?php 	
	// Initiliaze script
	if(isset($_GET['mode']) && $_GET['mode']=='exit')
	{
		setcookie("role","",time()-3600);
		unset($_COOKIE);
	}
	
	if (!isset($_COOKIE['role'])) 
		{
			header("Location: auth.php");
			exit;
		}
	$scrname = $_SERVER['PHP_SELF'];
	error_reporting(E_ALL ^ E_WARNING);
	$config = file("config.txt");
	$server_db = trim($config[1]);
	$user_db = trim($config[3]);
	$pass_db = trim($config[5]);
	$db_name = trim($config[7]);
	$connection = new mysqli($server_db,$user_db,$pass_db,$db_name);
	if ($connection->connect_errno) {
			echo "<h2><font color='red'>Failed to connect mysql database</font></h2>";
			exit;
		}
	$connection -> set_charset("utf8");
	error_reporting(E_ALL);
	
	if ($_COOKIE['role']=='admin')
		$admintools = true;
	else
		$admintools = false;
	
	function push_header_item($mode,$innerhtml) {
		global $scrname;
		echo "<a class='header-link item";
		if ($mode == "admintools") echo " admin-tools";
		if ($mode == "exit") echo " logout";
		if ($_GET['mode'] == $mode) echo " active";
		echo "' href='".$scrname."?mode=".$mode."'><div>".$innerhtml."</div></a>";
	}
	$state = $scrname."?mode=board";
	if (!isset($_GET['mode'])) header("Location: ".$state,false);
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<title>PHP7 Уроки</title>
		<link rel="stylesheet" type="text/css" href="/resource/css/main.css">
		<link rel="shortcut icon" href="/resource/icon/favicon.png"> 
		<script type="text/javascript" src="resource/js/interactive_buttons.js"></script>
		<script type="text/javascript" src="resource/js/collapsible.js"></script>
		<script type="text/javascript" src="resource/js/ckeditor/ckeditor.js"></script>
		<?php if ($admintools) echo "<script type='text/javascript' src='resource/js/admintools.js'></script>"; ?>
		</head>
		<body onload="activate_collapsible()">
			<script type="text/javascript">
				var to_top = new ToTopButton("Наверх");
				to_top.setClass("to-top-button");
				to_top.setClass("mainfont");
				document.body.appendChild(to_top);
			</script>
			<div class="skeleton-wrapper mainfont">
				<div class="header-bar">
					<?php
						push_header_item("board","Объявления");
						push_header_item("view_article","PHP7");
						push_header_item("feedback","Обратная связь");
						push_header_item("exit","Выход");
						if ($admintools) {
							push_header_item("admintools","Admin Tools");
						}
					?>
				</div>
				<?php
				if (isset($_GET['mode']) && $_GET['mode'] == "view_article")
				{
					echo "<div class='nav-panel'>";
					$sql = "SELECT * FROM containers ORDER BY container_sort_order";
					if (!$result_containers = $connection->query($sql)) {
						echo "<h2><font color='red'>Failed to execute query for container</font></h2>";
					}
					else {
						$sql = "SELECT * FROM articles ORDER BY article_sort_order";
						if (!$result_articles = $connection->query($sql)) {
							echo "<h2><font color='red'>Failed to execute query for articles</font></h2>";
						}
						while ($row_container =  $result_containers->fetch_assoc())
						{
							echo "<div class='item collapsible";
							$is_first = true;
							while($row_article = $result_articles->fetch_assoc()) {
								if ($is_first) {
								if (isset($_GET['container']) && ($_GET['container'] == $row_article['container_id'])) { echo " active";}
								echo "'>".$row_container['container_title']."</div><div class='content'>";
								$is_first = false;
								}
								echo "<a class='content-link".(isset($_GET['article'])&&$row_article['article_id']==$_GET['article']? " active":"")."' href='".$scrname."?mode=view_article&container=".$row_container['container_id']."&article=".$row_article['article_id']."'>".$row_article['article_title']."</a><br>";
							}
							echo "</div>";
						}
					}
					echo "</div>"; 
				}
				?>
				<div class="content-box">
				<?php
						if (isset($_GET['article']))
						{
							$get_article = mysqli_real_escape_string($connection,$_GET['article']);
							$sql = "SELECT content FROM articles WHERE article_id='".$get_article."'";
							if (!$result = $connection->query($sql)) {
								echo "<h2><font color='red'>Failed to execute query for content</font></h2>";
							}
							else {
								$article = $result->fetch_assoc();
								echo $article['content'];
							}
						}
						if ($admintools && $_GET['mode'] == "admintools")
						{
							$admtools_html = file("admintools.html");
							foreach($admtools_html as $str)
								echo $str;
						}	
				?></div>
			</div>
		</body>
</html>