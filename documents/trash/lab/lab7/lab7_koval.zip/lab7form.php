<html>
<head>
<meta charset=utf-8>
<title>Лабораторная работа №7</title>
<style>
p {
	margin-bottom: -7px;
}

wrapper {
	min-width: 300px;
	min-height: 700px;
}
input[type=submit] {
	position: absolute;
	left: 35px;
}

input[type=text] {
	width: 75px;
}
</style>
<script>
function check() {
	var inputs = document.querySelectorAll("input[type=text]");
	for(let i = 0; i < inputs.length; ++i)
	{
		if (inputs[i].value < 0 || inputs[i].value > 100 || isNaN(inputs[i].value)) {
			alert(inputs[i].value + " не является корректным процентом!");
			return false
		}
		if (inputs[i].value.length == 0) {
			alert("Число " + (i+1) + " не заполнено");
			return false;
		}
	}
	return true;
}

</script>
</head>
<body>
<h3>Создаём прямоугольную диаграмму</h3>
<form action=lab7diagram.php method=POST target="diagram" onSubmit="return check();">
	<div class="wrapper">
	<p>Число №1 <input type='text' name='n1'> %</p>
	<p>Число №2 <input type='text' name='n2'> %</p>
	<p>Число №3 <input type='text' name='n3'> %</p>
	<p>Число №4 <input type='text' name='n4'> %</p>
	<p>Число №5 <input type='text' name='n5'> %</p>
	<p><input type='submit' name='go' value='Показать диаграмму!'></p>
	</div>
</form>
</body>
<html>